#! /bin/sh

echo "hello world from container"